/**
 * @requires highcharts
 */
/*
 * Since v9.3.0, EMA technical indicator is part of indicators.js.
 * It's no longer necessary to load this file.
 */
'use strict';
